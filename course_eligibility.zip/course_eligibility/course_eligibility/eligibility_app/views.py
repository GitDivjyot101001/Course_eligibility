from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages


def index(request):
    """Redirect to admin page or show information page"""
    # Just redirect to admin
    return redirect('admin:index')
