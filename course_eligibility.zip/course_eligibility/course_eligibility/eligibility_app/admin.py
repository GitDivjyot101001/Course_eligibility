from django.contrib import admin
from django.urls import path
from django.shortcuts import render, redirect
from django.utils.html import format_html
from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_protect
from django.db import transaction
from django.template.response import TemplateResponse

from .models import (
    Course, SheetConnection, EligibilityEvaluation, CourseMapping,
    Student, StudentEnrollment
)
from .forms import SheetConnectionForm, EvaluationForm, CourseMappingForm
from .services.google_sheets import GoogleSheetsService
from .services.eligibility_evaluator import EligibilityEvaluator
from django.core.files.base import ContentFile

# Custom Admin Site
class EligibilityAdminSite(admin.AdminSite):
    site_header = "Course Eligibility Administration"
    site_title = "Course Eligibility Evaluator"
    index_title = "Dashboard"

    def index(self, request, extra_context=None):
        app_list = self.get_app_list(request)
        
        course_count = Course.objects.count()
        student_count = Student.objects.count()
        enrollment_count = StudentEnrollment.objects.count()
        evaluation_count = EligibilityEvaluation.objects.filter(status='completed').count()
        
        course_type_counts = {}
        course_type_absolute = {}
        
        type_codes = [t[0] for t in Course.COURSE_TYPES]
        
        if course_count > 0:
            for course_type in type_codes:
                type_count = Course.objects.filter(course_type=course_type).count()
                course_type_absolute[course_type] = type_count
                course_type_counts[course_type] = (type_count / course_count) * 100
        
        enrollment_stats = {
            'enrolled': StudentEnrollment.objects.filter(status='enrolled').count(),
            'completed': StudentEnrollment.objects.filter(status='completed').count(),
            'withdrawn': StudentEnrollment.objects.filter(status='withdrawn').count(),
            'failed': StudentEnrollment.objects.filter(status='failed').count(),
        }
        
        extra_context = extra_context or {}
        extra_context.update({
            'course_count': course_count,
            'sheet_count': SheetConnection.objects.count(),
            'evaluation_count': evaluation_count,
            'student_count': student_count,
            'enrollment_count': enrollment_count,
            'enrollment_stats': enrollment_stats,
            'course_type_counts': course_type_counts,
            'course_type_absolute': course_type_absolute,
        })
        
        return super().index(request, extra_context)

# Create custom admin site object
admin_site = EligibilityAdminSite(name='eligibility_admin')

# Admin Models
class CourseAdmin(admin.ModelAdmin):
    list_display = ('code', 'name', 'course_type', 'semester_offered', 'allow_repeat', 'get_prerequisites')
    list_filter = ('course_type', 'semester_offered', 'allow_repeat')
    search_fields = ('code', 'name')
    filter_horizontal = ('prerequisites',)
    
    def get_prerequisites(self, obj):
        return ", ".join([p.code for p in obj.prerequisites.all()])
    get_prerequisites.short_description = 'Prerequisites'


class CourseMappingInline(admin.StackedInline):
    model = CourseMapping
    form = CourseMappingForm
    can_delete = False
    extra = 1


class SheetConnectionAdmin(admin.ModelAdmin):
    list_display = ('name', 'semester', 'sheet_id', 'is_current_semester', 'created_by', 'updated_at')
    list_filter = ('is_current_semester', 'semester', 'created_by')
    search_fields = ('name', 'sheet_id', 'semester')
    readonly_fields = ('created_by', 'created_at', 'updated_at')
    form = SheetConnectionForm
    inlines = [CourseMappingInline]
    
    def save_model(self, request, obj, form, change):
        if not change:
            obj.created_by = request.user
        super().save_model(request, obj, form, change)


class EligibilityEvaluationAdmin(admin.ModelAdmin):
    list_display = ('id', 'current_sheet', 'previous_sheet', 'status', 'created_by', 'created_at', 'view_results', 'download_result')
    list_filter = ('status', 'created_by', 'created_at')
    readonly_fields = ('created_by', 'created_at', 'completed_at', 'status', 'result_summary')
    fields = ('current_sheet', 'previous_sheet', 'result_column', 'status', 'created_by', 'created_at', 'completed_at', 'result_summary')
    
    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('evaluate/', self.admin_site.admin_view(self.evaluate_view), name='eligibility_evaluate'),
            path('<int:evaluation_id>/results/', self.admin_site.admin_view(self.results_view), name='evaluation_results'),
        ]
        return custom_urls + urls
    
    def save_model(self, request, obj, form, change):
        if not change:
            obj.created_by = request.user
        super().save_model(request, obj, form, change)
    
    def view_results(self, obj):
        if obj.status == 'completed':
            return format_html('<a href="{}">View Results</a>', 
                f'/admin/eligibility_app/eligibilityevaluation/{obj.id}/results/')
        return "N/A"
    view_results.short_description = 'Results'

    def download_result(self, obj):
        if obj.result_file:
            return format_html('<a href="{}" download>Download Result</a>', obj.result_file.url)
        return "Not Available"
    download_result.short_description = 'Download Result'
    
    @method_decorator(staff_member_required)
    def evaluate_view(self, request):
        context = {
            'title': 'Eligibility Evaluation',
            'app_label': 'eligibility_app',
            'opts': EligibilityEvaluation._meta,
            'has_change_permission': self.has_change_permission(request),
        }
        
        if request.method == 'POST':
            form = EvaluationForm(request.POST, user=request.user)
            if form.is_valid():
                with transaction.atomic():
                    evaluation = form.save(commit=False)
                    evaluation.created_by = request.user
                    evaluation.status = 'processing'
                    evaluation.save()
                    
                    try:
                        gs_service = GoogleSheetsService()
                        evaluator = EligibilityEvaluator(gs_service)
                        
                        result = evaluator.evaluate_eligibility(evaluation)
                        
                        import pandas as pd
                        output = evaluator.get_result_file()
                        
                        if output:
                            evaluation.result_file.save('eligibility_result.xlsx', ContentFile(output.getvalue()))
                        
                        evaluation.set_completed(result)
                        
                        messages.success(request, 'Eligibility evaluation completed successfully.')
                        return redirect(f'admin:eligibility_app_eligibilityevaluation_change', object_id=evaluation.id)
                    except Exception as e:
                        evaluation.set_failed(str(e))
                        messages.error(request, f'Error during evaluation: {str(e)}')
                        return redirect('admin:eligibility_app_eligibilityevaluation_changelist')
        else:
            form = EvaluationForm(user=request.user)
        
        context['form'] = form
        return render(request, 'admin/eligibility_app/evaluation.html', context)
    
    @method_decorator(staff_member_required)
    def results_view(self, request, evaluation_id):
        try:
            evaluation = EligibilityEvaluation.objects.get(id=evaluation_id)
            
            if evaluation.status != 'completed':
                messages.warning(request, 'This evaluation has not been completed yet.')
                return redirect('admin:eligibility_app_eligibilityevaluation_changelist')
            
            gs_service = GoogleSheetsService()
            result_column = evaluation.result_column or "Eligibility Status"
            
            try:
                if evaluation.current_sheet.mock_data:
                    import json
                    import pandas as pd
                    mock_data = json.loads(evaluation.current_sheet.mock_data)
                    sheet_data = pd.DataFrame(mock_data)
                    
                    if result_column not in sheet_data.columns:
                        sheet_data[result_column] = "Eligible"
                        import random
                        for i in range(len(sheet_data)):
                            if random.random() < 0.2:
                                reasons = random.choice([
                                    "Already completed course",
                                    "Missing prerequisites",
                                    "Cannot take multiple SEC courses"
                                ])
                                sheet_data.at[i, result_column] = f"Not Eligible: {reasons}"
                    
                    sheet_data = sheet_data.to_dict('records')
                else:
                    sheet_data = gs_service.get_sheet_data(
                        evaluation.current_sheet.sheet_id,
                        evaluation.current_sheet.sheet_name
                    )
                
                total_entries = len(sheet_data)
                eligible_count = sum(1 for row in sheet_data if result_column in row and not str(row[result_column]).startswith('Not Eligible'))
                not_eligible_count = total_entries - eligible_count
                
                reason_counts = {}
                for row in sheet_data:
                    if result_column in row and str(row[result_column]).startswith('Not Eligible'):
                        reason = str(row[result_column])[13:]
                        if ':' in reason:
                            reason_type = reason.split(':')[0].strip()
                        else:
                            reason_type = reason.strip()
                        reason_counts[reason_type] = reason_counts.get(reason_type, 0) + 1
                
                reason_stats = []
                for reason, count in reason_counts.items():
                    percentage = (count / not_eligible_count * 100) if not_eligible_count > 0 else 0
                    reason_stats.append({
                        'reason': reason,
                        'count': count,
                        'percentage': round(percentage, 1)
                    })
                
                reason_stats.sort(key=lambda x: x['count'], reverse=True)
                
                processed_data = []
                for row in sheet_data:
                    record = {
                        'student_id': row.get('Student ID', row.get('student_id', '')),
                        'student_name': row.get('Student Name', row.get('student_name', '')),
                        'course_code': row.get('Course Code', row.get('course_code', '')),
                        'course_type': row.get('Course Type', row.get('course_type', '')),
                        'Eligibility_Status': row.get(result_column, '')
                    }
                    processed_data.append(record)
                
                context = {
                    'title': f'Evaluation Results: {evaluation}',
                    'evaluation': evaluation,
                    'sheet_data': processed_data,
                    'app_label': 'eligibility_app',
                    'opts': EligibilityEvaluation._meta,
                    'has_change_permission': self.has_change_permission(request),
                    'stats': {
                        'total': total_entries,
                        'eligible': eligible_count,
                        'eligible_percent': round(eligible_count / total_entries * 100 if total_entries > 0 else 0, 1),
                        'not_eligible': not_eligible_count,
                        'not_eligible_percent': round(not_eligible_count / total_entries * 100 if total_entries > 0 else 0, 1),
                        'reasons': reason_stats
                    }
                }
                return render(request, 'admin/eligibility_app/results.html', context)
            except Exception as e:
                messages.error(request, f'Error loading sheet data: {str(e)}')
                return redirect('admin:eligibility_app_eligibilityevaluation_change', object_id=evaluation.id)
        except EligibilityEvaluation.DoesNotExist:
            messages.error(request, 'Evaluation not found')
            return redirect('admin:eligibility_app_eligibilityevaluation_changelist')
        except Exception as e:
            messages.error(request, f'Error loading results: {str(e)}')
            return redirect('admin:eligibility_app_eligibilityevaluation_changelist')


class StudentEnrollmentInline(admin.TabularInline):
    model = StudentEnrollment
    extra = 1
    fields = ('course', 'semester', 'status', 'grade', 'sheet_connection')
    autocomplete_fields = ['course', 'sheet_connection']


class StudentAdmin(admin.ModelAdmin):
    list_display = ('student_id', 'name', 'get_completed_courses', 'get_current_courses')
    search_fields = ('student_id', 'name')
    inlines = [StudentEnrollmentInline]
    
    def get_completed_courses(self, obj):
        completed = obj.enrollments.filter(status='completed')
        return ', '.join([enrollment.course.code for enrollment in completed[:5]])
    get_completed_courses.short_description = 'Completed Courses'
    
    def get_current_courses(self, obj):
        current = obj.enrollments.filter(status='enrolled')
        return ', '.join([enrollment.course.code for enrollment in current[:5]])
    get_current_courses.short_description = 'Current Courses'


class StudentEnrollmentAdmin(admin.ModelAdmin):
    list_display = ('student', 'course', 'semester', 'status', 'grade')
    list_filter = ('status', 'semester', 'course__course_type')
    search_fields = ('student__student_id', 'student__name', 'course__code', 'course__name')
    autocomplete_fields = ['student', 'course', 'sheet_connection']

# Register Models with Custom Admin Site
admin_site.register(Course, CourseAdmin)
admin_site.register(SheetConnection, SheetConnectionAdmin)
admin_site.register(EligibilityEvaluation, EligibilityEvaluationAdmin)
admin_site.register(Student, StudentAdmin)
admin_site.register(StudentEnrollment, StudentEnrollmentAdmin)