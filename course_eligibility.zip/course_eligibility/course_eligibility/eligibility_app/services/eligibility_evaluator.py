import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Any, Optional
import json

from django.db.models import Q
from ..models import EligibilityEvaluation, Course, SheetConnection, CourseMapping, Student, StudentEnrollment
from .google_sheets import GoogleSheetsService


class EligibilityEvaluator:
    """
    Service class for evaluating student eligibility for courses
    based on their previous course history and prerequisites
    """
    
    def __init__(self, gs_service: GoogleSheetsService):
        """
        Initialize the eligibility evaluator
        
        Args:
            gs_service: An instance of GoogleSheetsService for data access
        """
        self.gs_service = gs_service
    
    def evaluate_eligibility(self, evaluation: EligibilityEvaluation) -> str:
        """
        Evaluate student eligibility for courses based on previous enrollment
        and course prerequisites
        
        Args:
            evaluation: The EligibilityEvaluation model instance
            
        Returns:
            str: A summary of the evaluation results
        """
        try:
            # Update evaluation status
            evaluation.status = 'processing'
            evaluation.save()
            
            # Load data from Google Sheets
            current_data = self._load_sheet_data(evaluation.current_sheet)
            previous_data = self._load_sheet_data(evaluation.previous_sheet)
            
            # Get column mappings
            current_mapping = self._get_column_mapping(evaluation.current_sheet)
            previous_mapping = self._get_column_mapping(evaluation.previous_sheet)
            
            # Standardize column names
            current_data = self._standardize_columns(current_data, current_mapping)
            previous_data = self._standardize_columns(previous_data, previous_mapping)
            
            # Prepare courses data
            courses = self._get_all_courses()
            
            # Sync data with the database
            self._sync_data_with_database(previous_data, evaluation.previous_sheet, courses, 'completed')
            self._sync_data_with_database(current_data, evaluation.current_sheet, courses, 'enrolled')
            
            # Evaluate eligibility
            results = self._perform_evaluation(current_data, previous_data, courses)
            
            # Update Google Sheet with results
            self._update_results(evaluation, current_data, results)
            
            # Prepare summary
            summary = self._prepare_summary(results)
            
            # Update evaluation status
            evaluation.set_completed(summary)
            
            return summary
        except Exception as e:
            # Set failed status
            evaluation.set_failed(str(e))
            raise e
    
    def _load_sheet_data(self, sheet_connection: SheetConnection) -> pd.DataFrame:
        """
        Load data from Google Sheets
        
        Args:
            sheet_connection: The SheetConnection model instance
            
        Returns:
            pd.DataFrame: The sheet data as a DataFrame
        """
        try:
            return self.gs_service.get_sheet_data(
                sheet_connection.sheet_id,
                sheet_connection.sheet_name,
                sheet_connection=sheet_connection
            )
        except Exception as e:
            raise Exception(f"Failed to load data from {sheet_connection}: {str(e)}")
    
    def _get_column_mapping(self, sheet_connection: SheetConnection) -> Dict[str, str]:
        """
        Get column mapping for a sheet connection
        
        Args:
            sheet_connection: The SheetConnection model instance
            
        Returns:
            Dict[str, str]: A mapping of sheet columns to standard column names
        """
        try:
            mapping = sheet_connection.column_mapping
            if not mapping:
                return {
                    'Student ID': 'student_id',
                    'Student Name': 'student_name',
                    'Course Code': 'course_code',
                    'Course Type': 'course_type',
                    'Grade': 'grade'
                }
            
            result = {
                mapping.student_id_column: 'student_id',
                mapping.student_name_column: 'student_name',
                mapping.course_code_column: 'course_code'
            }
            
            # Add optional mappings if present
            if hasattr(mapping, 'course_type_column') and mapping.course_type_column:
                result[mapping.course_type_column] = 'course_type'
            
            if hasattr(mapping, 'grade_column') and mapping.grade_column:
                result[mapping.grade_column] = 'grade'
                
            return result
        except Exception:
            # Return default mapping if custom mapping not available
            return {
                'Student ID': 'student_id',
                'Student Name': 'student_name',
                'Course Code': 'course_code',
                'Course Type': 'course_type',
                'Grade': 'grade'
            }
    
    def _standardize_columns(self, data: pd.DataFrame, mapping: Dict[str, str]) -> pd.DataFrame:
        """
        Standardize column names in a DataFrame based on mapping
        
        Args:
            data: The DataFrame to standardize
            mapping: The column mapping
            
        Returns:
            pd.DataFrame: DataFrame with standardized column names
        """
        # Create a copy of the DataFrame
        df = data.copy()
        
        # Rename columns based on mapping
        rename_dict = {}
        for sheet_col, std_col in mapping.items():
            if sheet_col in df.columns:
                rename_dict[sheet_col] = std_col
        
        if rename_dict:
            df = df.rename(columns=rename_dict)
        
        # Ensure required columns exist
        required_cols = ['student_id', 'student_name', 'course_code']
        for col in required_cols:
            if col not in df.columns:
                raise Exception(f"Required column '{col}' not found in sheet data")
        
        return df
    
    def _get_all_courses(self) -> Dict[str, Course]:
        """
        Get all courses and their prerequisites
        
        Returns:
            Dict[str, Course]: A dictionary of course objects keyed by course code
        """
        courses = {}
        for course in Course.objects.all().prefetch_related('prerequisites'):
            courses[course.code] = course
        
        return courses
    
    def _perform_evaluation(self, current_data: pd.DataFrame, 
                           previous_data: pd.DataFrame, 
                           courses: Dict[str, Course]) -> List[Dict[str, Any]]:
        """
        Perform eligibility evaluation for each student in current data
        
        Args:
            current_data: DataFrame with current semester data
            previous_data: DataFrame with previous semester data
            courses: Dictionary of course objects
            
        Returns:
            List[Dict[str, Any]]: List of evaluation results
        """
        results = []
        
        # Group by student_id
        current_by_student = current_data.groupby('student_id')
        previous_by_student = previous_data.groupby('student_id')
        
        # For each student in current data
        for student_id, student_df in current_by_student:
            student_name = student_df['student_name'].iloc[0]
            
            # Get student's previous courses with details
            previous_courses = set()
            previous_course_types = {}  # Track course types student has completed
            previous_course_objects = []
            
            if student_id in previous_by_student.groups:
                previous_student_df = previous_by_student.get_group(student_id)
                
                # Store unique course codes
                previous_courses = set(previous_student_df['course_code'].unique())
                
                # Track completed course types (GE/SEC/VAC)
                for _, prev_row in previous_student_df.iterrows():
                    course_code = prev_row['course_code']
                    if course_code in courses:
                        course_obj = courses[course_code]
                        previous_course_objects.append(course_obj)
                        
                        # Count course by type
                        course_type = course_obj.course_type
                        if course_type in previous_course_types:
                            previous_course_types[course_type] += 1
                        else:
                            previous_course_types[course_type] = 1
            
            # Get current semester course types
            current_courses_by_type = {}
            for _, row in student_df.iterrows():
                course_code = row['course_code']
                if course_code in courses:
                    course_type = courses[course_code].course_type
                    if course_type in current_courses_by_type:
                        current_courses_by_type[course_type].append(course_code)
                    else:
                        current_courses_by_type[course_type] = [course_code]
            
            # Evaluate each course for this student
            for _, row in student_df.iterrows():
                course_code = row['course_code']
                
                # Skip if course code is missing or invalid
                if pd.isna(course_code) or course_code == '':
                    continue
                
                # Initialize result
                result = {
                    'student_id': student_id,
                    'student_name': student_name,
                    'course_code': course_code,
                    'eligible': True,
                    'reasons': []
                }
                
                # Get course object if it exists
                course_obj = courses.get(course_code)
                if not course_obj:
                    # Course not in database, assume eligible since we can't check rules
                    results.append(result)
                    continue
                
                # 1. Check if student already took this course and course doesn't allow repeats
                if course_code in previous_courses and not course_obj.allow_repeat:
                    result['eligible'] = False
                    result['reasons'].append(f"Already completed {course_code}")
                
                # 2. Check prerequisites
                prerequisites = list(course_obj.prerequisites.all())
                if prerequisites:
                    for prereq in prerequisites:
                        if prereq.code not in previous_courses:
                            result['eligible'] = False
                            result['reasons'].append(f"Missing prerequisite: {prereq.code}")
                
                # 3. Special handling for SEC and VAC course types
                if course_obj.course_type in ['SEC', 'VAC']:
                    # Rule 1: For SEC/VAC, student can't take the same type more than once in same semester
                    same_type_in_current = current_courses_by_type.get(course_obj.course_type, [])
                    if len(same_type_in_current) > 1 and course_code in same_type_in_current:
                        multiple_courses = ", ".join(same_type_in_current)
                        result['eligible'] = False
                        result['reasons'].append(
                            f"Cannot enroll in multiple {course_obj.course_type} " 
                            f"courses in same semester: {multiple_courses}"
                        )
                    
                    # Rule 2: Check if student has already completed a course of this type
                    completed_of_same_type = [c for c in previous_course_objects 
                                            if c.course_type == course_obj.course_type]
                    
                    if completed_of_same_type and not course_obj.allow_repeat:
                        course_list = ", ".join([c.code for c in completed_of_same_type])
                        result['eligible'] = False
                        result['reasons'].append(
                            f"Already completed a {course_obj.course_type} course: {course_list}"
                        )
                        
                # 4. Additional rules for GE courses
                if course_obj.course_type == 'GE':
                    # GE courses have a semester limit
                    ge_limit = 2  # Maximum GE courses per semester
                    current_ge_courses = current_courses_by_type.get('GE', [])
                    if len(current_ge_courses) > ge_limit:
                        result['eligible'] = False
                        result['reasons'].append(
                            f"Student can take maximum {ge_limit} GE courses per semester"
                        )
                
                # 5. CORE course progression check
                if course_obj.course_type == 'CORE':
                    # Check for numeric sequence in course code (101, 201, 301, 401)
                    if course_obj.code.endswith('301') or course_obj.code.endswith('401'):
                        # Advanced courses need prerequisites based on department
                        prefix = course_obj.code.split('-')[0]  # Get department code (CS, MATH, etc)
                        
                        # Define required courses based on level
                        required_lower = []
                        if course_obj.code.endswith('301'):
                            # 301 courses typically need 201 completed
                            required_lower = [f"{prefix}-201"]
                        elif course_obj.code.endswith('401'):
                            # 401 courses typically need 301 completed
                            required_lower = [f"{prefix}-301"]
                            
                        missing = []
                        for req in required_lower:
                            if req not in previous_courses:
                                missing.append(req)
                                
                        if missing:
                            result['eligible'] = False
                            missing_str = ', '.join(missing)
                            result['reasons'].append(
                                f"Required course sequence: complete {missing_str} before taking {course_code}"
                            )
                        
                # Add other course type-specific rules here as needed
                
                results.append(result)
        
        return results
    
    def _update_results(self, evaluation: EligibilityEvaluation, 
                       current_data: pd.DataFrame, 
                       results: List[Dict[str, Any]]) -> bool:
        """
        Update Google Sheet with evaluation results
        
        Args:
            evaluation: The EligibilityEvaluation model instance
            current_data: DataFrame with current semester data
            results: List of evaluation results
            
        Returns:
            bool: True if update was successful
        """
        # Convert results to a DataFrame
        results_df = pd.DataFrame(results)
        
        # Create a mapping of (student_id, course_code) to eligibility status
        result_mapping = {}
        for result in results:
            key = (result['student_id'], result['course_code'])
            status = "Eligible" if result['eligible'] else "Not Eligible: " + ", ".join(result['reasons'])
            result_mapping[key] = status
        
        # Add eligibility status to current_data
        current_data[evaluation.result_column] = current_data.apply(
            lambda row: result_mapping.get((row['student_id'], row['course_code']), ""),
            axis=1
        )
        
        # Update Google Sheet
        try:
            self.gs_service.update_sheet_data(
                evaluation.current_sheet.sheet_id,
                evaluation.current_sheet.sheet_name,
                current_data,
                sheet_connection=evaluation.current_sheet
            )
            return True
        except Exception as e:
            raise Exception(f"Failed to update sheet with results: {str(e)}")
    
    def _sync_data_with_database(self, data: pd.DataFrame, 
                            sheet_connection: SheetConnection,
                            courses: Dict[str, Course],
                            enrollment_status: str = 'enrolled') -> None:
        """
        Synchronize data from Google Sheets with the database
        
        Args:
            data: DataFrame containing sheet data
            sheet_connection: The sheet connection model
            courses: Dictionary of course objects
            enrollment_status: The enrollment status ('enrolled', 'completed', etc.)
        """
        from django.db import transaction
        
        # Group by student_id
        if 'student_id' not in data.columns:
            return
            
        student_groups = data.groupby('student_id')
        
        with transaction.atomic():
            # Process each student
            for student_id, student_df in student_groups:
                if pd.isna(student_id) or student_id == '':
                    continue
                    
                # Get student name from first row
                student_name = student_df['student_name'].iloc[0]
                if pd.isna(student_name):
                    student_name = f"Student {student_id}"
                
                # Create or get student
                student, created = Student.objects.get_or_create(
                    student_id=student_id,
                    defaults={'name': student_name}
                )
                
                # Process each course for this student
                for _, row in student_df.iterrows():
                    course_code = row['course_code']
                    
                    # Skip invalid course codes
                    if pd.isna(course_code) or course_code == '':
                        continue
                    
                    # Get course object
                    course = courses.get(course_code)
                    if not course:
                        # Try to find in database
                        try:
                            course = Course.objects.get(code=course_code)
                            courses[course_code] = course  # Update cache
                        except Course.DoesNotExist:
                            # Skip if course doesn't exist
                            continue
                    
                    # Get grade if available
                    grade = None
                    if 'grade' in row and not pd.isna(row['grade']):
                        grade = row['grade']
                    
                    # Create or update enrollment
                    enrollment, created = StudentEnrollment.objects.update_or_create(
                        student=student,
                        course=course,
                        semester=sheet_connection.semester,
                        defaults={
                            'status': enrollment_status,
                            'grade': grade,
                            'sheet_connection': sheet_connection
                        }
                    )

    def _prepare_summary(self, results: List[Dict[str, Any]]) -> str:
        """
        Prepare a summary of evaluation results
        
        Args:
            results: List of evaluation results
            
        Returns:
            str: A summary of the evaluation results
        """
        total = len(results)
        eligible = sum(1 for r in results if r['eligible'])
        not_eligible = total - eligible
        
        # Count reasons for ineligibility
        reason_counts = {}
        for result in results:
            if not result['eligible']:
                for reason in result['reasons']:
                    reason_type = reason.split(':')[0]
                    reason_counts[reason_type] = reason_counts.get(reason_type, 0) + 1
        
        # Format summary
        summary = (
            f"Total students evaluated: {total}\n"
            f"Eligible: {eligible} ({(eligible/total)*100:.1f}%)\n"
            f"Not Eligible: {not_eligible} ({(not_eligible/total)*100:.1f}%)\n\n"
        )
        
        if reason_counts:
            summary += "Reasons for ineligibility:\n"
            for reason, count in reason_counts.items():
                summary += f"- {reason}: {count} ({(count/not_eligible)*100:.1f}%)\n"
        
        return summary
