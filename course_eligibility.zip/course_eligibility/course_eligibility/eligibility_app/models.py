from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
import json


class Course(models.Model):
    """Model for course information"""
    COURSE_TYPES = (
        ('GE', 'Generic Elective'),
        ('SEC', 'Skill Enhancement Course'),
        ('VAC', 'Value-Added Course'),
        ('CORE', 'Core Course'),
        ('OTHER', 'Other'),
    )
    
    code = models.CharField(max_length=20, unique=True, help_text="Course code (e.g., GE-PYTHON)")
    name = models.CharField(max_length=100, help_text="Course name")
    course_type = models.CharField(
        max_length=10, 
        choices=COURSE_TYPES,
        default='OTHER',
        help_text="Type of course (GE, SEC, VAC, etc.)"
    )
    semester_offered = models.CharField(
        max_length=20,
        blank=True,
        help_text="Semester when this course is typically offered (e.g., Fall 2023)"
    )
    prerequisites = models.ManyToManyField(
        'self', 
        blank=True, 
        symmetrical=False, 
        related_name='required_for',
        help_text="Prerequisite courses that must be completed before enrolling"
    )
    allow_repeat = models.BooleanField(
        default=False, 
        help_text="Whether a student is allowed to take this course multiple times"
    )
    
    def __str__(self):
        return f"{self.code} - {self.name} ({self.get_course_type_display()})"
    
    class Meta:
        ordering = ['code']
        verbose_name = 'Course'
        verbose_name_plural = 'Courses'


class SheetConnection(models.Model):
    """Model to store Google Sheet connection details"""
    name = models.CharField(max_length=100, help_text="A descriptive name for this connection")
    sheet_id = models.CharField(max_length=100, help_text="Google Sheet ID")
    sheet_name = models.CharField(max_length=100, help_text="Tab/Sheet name within the Google Sheet")
    is_current_semester = models.BooleanField(default=False, help_text="Is this the current semester data?")
    semester = models.CharField(max_length=20, help_text="Semester identifier (e.g., Fall 2023)")
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sheet_connections')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    mock_data = models.TextField(blank=True, null=True, help_text="JSON mock data for testing purposes")
    
    class Meta:
        verbose_name = 'Sheet Connection'
        verbose_name_plural = 'Sheet Connections'
        
    def __str__(self):
        return f"{self.name} ({self.semester})"
        
    def get_mock_data(self):
        """Get the mock data as a Python object"""
        if not self.mock_data:
            return []
        return json.loads(self.mock_data)


class EligibilityEvaluation(models.Model):
    """Model to store eligibility evaluation results"""
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('processing', 'Processing'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
    )
    
    current_sheet = models.ForeignKey(
        SheetConnection, 
        on_delete=models.CASCADE, 
        related_name='current_evaluations'
    )
    previous_sheet = models.ForeignKey(
        SheetConnection, 
        on_delete=models.CASCADE, 
        related_name='previous_evaluations'
    )
    result_column = models.CharField(
        max_length=50, 
        default="Eligibility Status",
        help_text="Column name for results in the Google Sheet"
    )
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    result_summary = models.TextField(blank=True, null=True)
    
    def set_completed(self, summary):
        self.status = 'completed'
        self.completed_at = timezone.now()
        self.result_summary = summary
        self.save()
    
    def set_failed(self, error_message):
        self.status = 'failed'
        self.completed_at = timezone.now()
        self.result_summary = error_message
        self.save()
    
    class Meta:
        verbose_name = 'Eligibility Evaluation'
        verbose_name_plural = 'Eligibility Evaluations'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"Evaluation {self.id} - {self.current_sheet.semester}"


class CourseMapping(models.Model):
    """Model to store column mappings for Google Sheets"""
    sheet_connection = models.OneToOneField(
        SheetConnection, 
        on_delete=models.CASCADE,
        related_name='column_mapping'
    )
    student_id_column = models.CharField(max_length=50, default="Student ID")
    student_name_column = models.CharField(max_length=50, default="Student Name")
    course_code_column = models.CharField(max_length=50, default="Course Code")
    course_type_column = models.CharField(max_length=50, default="Course Type", 
                                          help_text="Column that indicates if course is GE/SEC/VAC")
    grade_column = models.CharField(max_length=50, blank=True, 
                                    help_text="Column containing grades (if applicable)")
    mapping_data = models.TextField(
        blank=True, 
        help_text="JSON mapping of column names to standardized fields"
    )
    
    def set_mapping(self, mapping_dict):
        self.mapping_data = json.dumps(mapping_dict)
        self.save()
    
    def get_mapping(self):
        if not self.mapping_data:
            return {}
        return json.loads(self.mapping_data)
    
    class Meta:
        verbose_name = 'Course Mapping'
        verbose_name_plural = 'Course Mappings'
    
    def __str__(self):
        return f"Mapping for {self.sheet_connection.name}"


class Student(models.Model):
    """Model to store student information"""
    student_id = models.CharField(max_length=50, unique=True, help_text="Unique student identifier")
    name = models.CharField(max_length=100, help_text="Student name")
    
    def __str__(self):
        return f"{self.student_id} - {self.name}"
    
    class Meta:
        ordering = ['student_id']
        verbose_name = 'Student'
        verbose_name_plural = 'Students'
        
    def has_completed_course(self, course_code):
        """Check if student has already completed a specific course"""
        return self.enrollments.filter(course__code=course_code, status='completed').exists()
    
    def has_completed_prerequisites(self, course):
        """Check if student has completed all prerequisites for a course"""
        prerequisites = course.prerequisites.all()
        
        # If no prerequisites, student is eligible
        if not prerequisites.exists():
            return True
            
        # Check each prerequisite
        for prereq in prerequisites:
            if not self.has_completed_course(prereq.code):
                return False
                
        return True
        
    def get_completed_course_types(self):
        """Get count of each type of course completed by the student"""
        result = {}
        for course_type, _ in Course.COURSE_TYPES:
            count = self.enrollments.filter(
                course__course_type=course_type, 
                status='completed'
            ).count()
            result[course_type] = count
        return result


class StudentEnrollment(models.Model):
    """Model to track student enrollments in courses"""
    STATUS_CHOICES = (
        ('enrolled', 'Currently Enrolled'),
        ('completed', 'Completed'),
        ('withdrawn', 'Withdrawn'),
        ('failed', 'Failed'),
    )
    
    student = models.ForeignKey(
        Student,
        on_delete=models.CASCADE,
        related_name='enrollments'
    )
    course = models.ForeignKey(
        Course,
        on_delete=models.CASCADE,
        related_name='enrollments'
    )
    semester = models.CharField(max_length=20, help_text="Semester of enrollment (e.g., Fall 2023)")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='enrolled')
    grade = models.CharField(max_length=10, blank=True, null=True)
    sheet_connection = models.ForeignKey(
        SheetConnection,
        on_delete=models.CASCADE,
        related_name='enrollments'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.student.student_id} - {self.course.code} ({self.semester})"
    
    class Meta:
        unique_together = [['student', 'course', 'semester']]
        ordering = ['-created_at']
        verbose_name = 'Student Enrollment'
        verbose_name_plural = 'Student Enrollments'
