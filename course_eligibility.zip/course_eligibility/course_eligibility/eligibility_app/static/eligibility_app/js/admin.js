// admin.js - Custom JavaScript for the Course Eligibility Evaluator

document.addEventListener('DOMContentLoaded', () => {
    // Add animation to messages
    const messages = document.querySelectorAll('.messagelist li');
    messages.forEach((message) => {
        message.style.opacity = '0';
        message.style.transform = 'translateY(-10px)';
        message.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
        
        setTimeout(() => {
            message.style.opacity = '1';
            message.style.transform = 'translateY(0)';
        }, 100);
        
        // Auto-dismiss messages after 5 seconds
        if (!message.classList.contains('error')) {
            setTimeout(() => {
                message.style.opacity = '0';
                message.style.transform = 'translateY(-10px)';
                setTimeout(() => {
                    message.remove();
                }, 300);
            }, 5000);
        }
    });
    
    // Add hover effect to table rows
    const tableRows = document.querySelectorAll('#result_list tbody tr');
    tableRows.forEach((row) => {
        row.style.transition = 'background-color 0.2s ease';
    });
    
    // Enhance form inputs
    const formInputs = document.querySelectorAll('input[type="text"], input[type="password"], textarea, select');
    formInputs.forEach((input) => {
        input.style.transition = 'border-color 0.3s ease, box-shadow 0.3s ease';
        
        input.addEventListener('focus', () => {
            input.style.borderColor = '#3498db';
            input.style.boxShadow = '0 0 0 2px rgba(52, 152, 219, 0.2)';
        });
        
        input.addEventListener('blur', () => {
            input.style.borderColor = '';
            input.style.boxShadow = '';
        });
    });
    
    // Add smooth scroll to anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Add confirm dialogs to delete actions
    const deleteButtons = document.querySelectorAll('.deletelink');
    deleteButtons.forEach((button) => {
        button.addEventListener('click', (e) => {
            if (!confirm('Are you sure you want to delete this item? This action cannot be undone.')) {
                e.preventDefault();
            }
        });
    });
    
    // Enhance eligibility evaluation interface if present
    const evaluationForm = document.querySelector('.eligibility-evaluation-form');
    if (evaluationForm) {
        const submitButton = evaluationForm.querySelector('input[type="submit"]');
        if (submitButton) {
            submitButton.classList.add('enhanced-button');
            submitButton.value = '🔍 Evaluate Eligibility';
            
            // Add loading state to button
            submitButton.addEventListener('click', () => {
                submitButton.value = 'Processing...';
                submitButton.disabled = true;
                evaluationForm.classList.add('processing');
                
                // Show a loading indicator
                const loadingDiv = document.createElement('div');
                loadingDiv.className = 'loading-indicator';
                loadingDiv.innerHTML = `
                    <div class="spinner"></div>
                    <p>Evaluating student eligibility...</p>
                `;
                evaluationForm.appendChild(loadingDiv);
            });
        }
    }
    
    // Add tooltips to help text
    const helpTexts = document.querySelectorAll('.help');
    helpTexts.forEach((helpText) => {
        const helpIcon = document.createElement('span');
        helpIcon.className = 'help-icon';
        helpIcon.textContent = 'ℹ️';
        helpIcon.title = helpText.textContent;
        
        helpText.style.display = 'none';
        helpText.parentNode.insertBefore(helpIcon, helpText);
    });
    
    // Add card-like effect to dashboard modules
    const dashboardModules = document.querySelectorAll('.dashboard .module');
    dashboardModules.forEach((module) => {
        module.style.transition = 'transform 0.2s ease, box-shadow 0.2s ease';
        
        module.addEventListener('mouseenter', () => {
            module.style.transform = 'translateY(-5px)';
            module.style.boxShadow = '0 5px 15px rgba(0,0,0,0.1)';
        });
        
        module.addEventListener('mouseleave', () => {
            module.style.transform = '';
            module.style.boxShadow = '';
        });
    });
});