// JavaScript functionality for evaluation page
document.addEventListener('DOMContentLoaded', function() {
    // Initialize any interactive elements
    initializeSheetPreviews();
    setupFormValidation();
});

function initializeSheetPreviews() {
    // Add preview functionality for sheet connections
    const currentSheetSelect = document.getElementById('id_current_sheet');
    const previousSheetSelect = document.getElementById('id_previous_sheet');
    
    if (currentSheetSelect && previousSheetSelect) {
        // Add event listeners to show previews when sheets are selected
        currentSheetSelect.addEventListener('change', function() {
            showSheetPreview('current', this.value);
        });
        
        previousSheetSelect.addEventListener('change', function() {
            showSheetPreview('previous', this.value);
        });
    }
}

function showSheetPreview(type, sheetId) {
    // This would be implemented with AJAX to fetch sheet preview data
    // For demonstration, we'll just show a placeholder
    const previewContainer = document.getElementById(`${type}-sheet-preview`);
    
    if (previewContainer && sheetId) {
        previewContainer.innerHTML = `<div class="spinner-border text-primary" role="status">
            <span class="sr-only">Loading...</span>
        </div>
        <p class="mt-2">Loading preview for sheet ID: ${sheetId}...</p>`;
        
        // In a real implementation, this would make an AJAX request to get sheet data
        // and display it in a table
    }
}

function setupFormValidation() {
    // Add client-side validation for the evaluation form
    const evaluationForm = document.querySelector('.eligibility-form');
    
    if (evaluationForm) {
        evaluationForm.addEventListener('submit', function(event) {
            const currentSheet = document.getElementById('id_current_sheet').value;
            const previousSheet = document.getElementById('id_previous_sheet').value;
            
            if (!currentSheet || !previousSheet) {
                event.preventDefault();
                showAlert('Please select both current and previous semester sheets.');
                return false;
            }
            
            if (currentSheet === previousSheet) {
                event.preventDefault();
                showAlert('Current and previous sheets must be different.');
                return false;
            }
            
            // Show loading indicator
            showLoadingOverlay();
            return true;
        });
    }
}

function showAlert(message) {
    // Display an alert message on the page
    const alertContainer = document.createElement('div');
    alertContainer.className = 'alert alert-danger alert-dismissible fade show';
    alertContainer.innerHTML = `
        ${message}
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    `;
    
    const formContainer = document.querySelector('.eligibility-form');
    formContainer.prepend(alertContainer);
    
    // Scroll to alert
    alertContainer.scrollIntoView({ behavior: 'smooth' });
}

function showLoadingOverlay() {
    // Show a loading overlay during evaluation
    const overlay = document.createElement('div');
    overlay.className = 'loading-overlay';
    overlay.innerHTML = `
        <div class="d-flex justify-content-center align-items-center h-100">
            <div class="text-center">
                <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                    <span class="sr-only">Processing...</span>
                </div>
                <h5 class="mt-3 text-white">Evaluating Eligibility...</h5>
                <p class="text-white">This may take a moment depending on the size of your data.</p>
            </div>
        </div>
    `;
    
    // Apply styles
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100%';
    overlay.style.height = '100%';
    overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
    overlay.style.zIndex = '9999';
    
    document.body.appendChild(overlay);
}
