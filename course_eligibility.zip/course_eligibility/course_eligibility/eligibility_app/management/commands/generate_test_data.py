import json
import random
import requests
from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from eligibility_app.models import Course, SheetConnection, CourseMapping
from django.utils import timezone

class Command(BaseCommand):
    help = 'Generate test data for the Course Eligibility system using Mockaroo'

    def add_arguments(self, parser):
        parser.add_argument('--courses', type=int, default=10, help='Number of courses to create')
        parser.add_argument('--user_id', type=int, default=1, help='User ID to associate with sheet connections')
        parser.add_argument('--previous_students', type=int, default=30, help='Number of students in previous semester')
        parser.add_argument('--current_students', type=int, default=30, help='Number of students in current semester')

    def handle(self, *args, **options):
        num_courses = options['courses']
        user_id = options['user_id']
        num_previous_students = options['previous_students']
        num_current_students = options['current_students']

        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            self.stdout.write(self.style.ERROR(f'User with ID {user_id} does not exist'))
            return

        # Generate course data
        self.generate_courses(num_courses)
        
        # Generate previous semester data
        prev_sheet_data = self.generate_student_data(num_previous_students, "Previous Semester")
        
        # Generate current semester data
        curr_sheet_data = self.generate_student_data(num_current_students, "Current Semester", prev_sheet_data)
        
        # Create sheet connections for test data
        self.create_sheet_connections(user, prev_sheet_data, curr_sheet_data)
        
        self.stdout.write(self.style.SUCCESS('Successfully generated test data'))

    def generate_courses(self, num_courses):
        """Generate test courses with prerequisites"""
        self.stdout.write('Generating courses...')
        
        # Clear existing courses
        Course.objects.all().delete()
        
        # Create course prefixes
        prefixes = ['CS', 'MATH', 'ENG', 'SCI', 'BIO', 'PHYS', 'CHEM', 'HIST']
        course_levels = ['101', '201', '301', '401', 'INTRO', 'ADV']
        course_topics = ['PYTHON', 'JAVA', 'DATABASE', 'ALGORITHMS', 'AI', 'ML', 
                        'WEBDEV', 'NETWORKS', 'SECURITY', 'CLOUD']
        
        # Determine number of each course type to create
        # We want a mix of different course types with specific naming conventions
        ge_count = int(num_courses * 0.25)  # 25% Generic Electives
        sec_count = int(num_courses * 0.15)  # 15% Skill Enhancement Courses
        vac_count = int(num_courses * 0.1)   # 10% Value-Added Courses
        core_count = num_courses - ge_count - sec_count - vac_count  # The rest are Core Courses
        
        # Create courses
        courses = []
        
        # 1. Generate GE courses (Generic Electives)
        for i in range(ge_count):
            prefix = 'GE'
            code_part = random.choice(course_topics)
            code = f"{prefix}-{code_part}"
            name = f"Generic Elective: {code_part}"
            
            # Check if course already exists
            if Course.objects.filter(code=code).exists():
                continue
            
            # GE courses typically allow repeats (different topics under same discipline)
            course = Course.objects.create(
                code=code,
                name=name,
                course_type='GE',
                allow_repeat=random.choice([True, False]),  # Some GE courses allow repeats
                semester_offered=random.choice(['Fall 2024', 'Spring 2025', 'Both'])
            )
            courses.append(course)
        
        # 2. Generate SEC courses (Skill Enhancement)
        for i in range(sec_count):
            prefix = 'SEC'
            code_part = random.choice(course_topics)
            code = f"{prefix}-{code_part}"
            name = f"Skill Enhancement: {code_part}"
            
            if Course.objects.filter(code=code).exists():
                continue
            
            # SEC courses typically don't allow repeats
            course = Course.objects.create(
                code=code,
                name=name,
                course_type='SEC',
                allow_repeat=False,  # SEC courses don't allow repeats
                semester_offered=random.choice(['Fall 2024', 'Spring 2025', 'Both'])
            )
            courses.append(course)
        
        # 3. Generate VAC courses (Value-Added)
        for i in range(vac_count):
            prefix = 'VAC'
            code_part = random.choice(course_topics)
            code = f"{prefix}-{code_part}"
            name = f"Value-Added: {code_part}"
            
            if Course.objects.filter(code=code).exists():
                continue
            
            # VAC courses don't allow repeats
            course = Course.objects.create(
                code=code,
                name=name,
                course_type='VAC',
                allow_repeat=False,  # VAC courses don't allow repeats
                semester_offered=random.choice(['Fall 2024', 'Spring 2025', 'Both'])
            )
            courses.append(course)
        
        # 4. Generate CORE courses
        for i in range(core_count):
            prefix = random.choice(prefixes)
            level = random.choice(course_levels)
            code = f"{prefix}-{level}"
            name = f"{prefix} {level} Core Course"
            
            if Course.objects.filter(code=code).exists():
                continue
            
            # CORE courses typically don't allow repeats
            course = Course.objects.create(
                code=code,
                name=name,
                course_type='CORE',
                allow_repeat=False,  # Core courses typically don't allow repeats
                semester_offered=random.choice(['Fall 2024', 'Spring 2025', 'Both'])
            )
            courses.append(course)
        
        # Add prerequisites (ensure no circular dependencies)
        for i, course in enumerate(courses):
            # For cores, add 0-2 prerequisites from core courses
            if course.course_type == 'CORE':
                core_courses = [c for c in courses[:i] if c.course_type == 'CORE']
                num_prereqs = random.randint(0, min(2, len(core_courses)))
                if num_prereqs > 0 and core_courses:
                    prereqs = random.sample(core_courses, num_prereqs)
                    for prereq in prereqs:
                        course.prerequisites.add(prereq)
                        
            # For SEC courses, add 1 prerequisite from core courses
            elif course.course_type == 'SEC':
                core_courses = [c for c in courses if c.course_type == 'CORE']
                if core_courses:
                    prereq = random.choice(core_courses)
                    course.prerequisites.add(prereq)
        
        self.stdout.write(self.style.SUCCESS(f'Created {len(courses)} courses with different types:'))
        self.stdout.write(f'  - GE (Generic Elective): {ge_count}')
        self.stdout.write(f'  - SEC (Skill Enhancement): {sec_count}')
        self.stdout.write(f'  - VAC (Value-Added): {vac_count}')
        self.stdout.write(f'  - CORE: {core_count}')

    def generate_student_data(self, num_students, semester_name, previous_data=None):
        """Generate mock student data for a semester"""
        self.stdout.write(f'Generating {semester_name} student data...')
        
        # Get all courses
        all_courses = list(Course.objects.all())
        if not all_courses:
            self.stdout.write(self.style.ERROR('No courses found. Generate courses first.'))
            return []
        
        students = []
        # If previous data exists, use a subset of the same students
        student_ids = []
        if previous_data and len(previous_data) > 0:
            # Use 70% of previous students
            unique_prev_students = set([s['Student ID'] for s in previous_data])
            prev_ids = list(unique_prev_students)[:int(0.7 * len(unique_prev_students))]
            student_ids.extend(prev_ids)
        
        # Add new student IDs if needed
        while len(student_ids) < num_students:
            new_id = f"S{random.randint(10000, 99999)}"
            if new_id not in student_ids:
                student_ids.append(new_id)
        
        # Group courses by type
        course_by_type = {}
        for course_type in ['GE', 'SEC', 'VAC', 'CORE']:
            course_by_type[course_type] = [c for c in all_courses if c.course_type == course_type]
        
        # Grade options
        grades = ['A+', 'A', 'B+', 'B', 'C+', 'C', 'D', 'F', 'Incomplete']
        
        # Generate student data
        for student_id in student_ids:
            # For previous semester data, include completed & grades
            if 'Previous' in semester_name:
                # Students have 3-6 courses in previous semester
                num_courses = random.randint(3, 6)
                
                # Select courses with a reasonable distribution
                selected_courses = []
                
                # 1-2 CORE courses
                core_count = min(random.randint(1, 2), len(course_by_type['CORE']))
                if core_count > 0 and course_by_type['CORE']:
                    selected_courses.extend(random.sample(course_by_type['CORE'], core_count))
                
                # 1 SEC course
                if course_by_type['SEC'] and random.random() > 0.3:  # 70% chance
                    selected_courses.append(random.choice(course_by_type['SEC']))
                
                # 0-1 VAC courses
                if course_by_type['VAC'] and random.random() > 0.5:  # 50% chance
                    selected_courses.append(random.choice(course_by_type['VAC']))
                
                # Fill the rest with GE courses
                remaining = num_courses - len(selected_courses)
                if remaining > 0 and course_by_type['GE']:
                    ge_count = min(remaining, len(course_by_type['GE']))
                    selected_courses.extend(random.sample(course_by_type['GE'], ge_count))
                
                # Ensure we have courses
                if not selected_courses:
                    selected_courses = random.sample(all_courses, min(num_courses, len(all_courses)))
                
                # Create student entries with grades for previous semester
                for course in selected_courses:
                    grade = random.choice(grades)
                    # Higher probability of passing grades
                    if random.random() < 0.8:  # 80% passing rate
                        grade = random.choice(['A+', 'A', 'B+', 'B', 'C+', 'C'])
                    
                    student_entry = {
                        'Student ID': student_id,
                        'Student Name': f"Student {student_id[1:]}",
                        'Course Code': course.code,
                        'Course Type': course.course_type,
                        'Grade': grade
                    }
                    students.append(student_entry)
            else:
                # Current semester: students take 2-4 courses
                num_courses = random.randint(2, 4)
                
                # Get completed courses for this student
                completed_courses = []
                if previous_data:
                    completed_courses = [entry['Course Code'] for entry in previous_data 
                                         if entry['Student ID'] == student_id]
                
                # Filter out completed SEC/VAC courses (students shouldn't repeat these)
                available_courses = []
                for course in all_courses:
                    # Skip courses the student already completed, unless they allow repeats
                    if course.code in completed_courses and not course.allow_repeat:
                        continue
                    available_courses.append(course)
                
                # Select a mix of course types
                selected_courses = []
                
                # Student must take at least one core course if available
                core_courses = [c for c in available_courses if c.course_type == 'CORE']
                if core_courses:
                    selected_courses.append(random.choice(core_courses))
                
                # Only one SEC/VAC course per semester
                sec_vac_taken = False
                
                # Randomly select remaining courses
                remaining_courses = [c for c in available_courses if c not in selected_courses]
                while len(selected_courses) < num_courses and remaining_courses:
                    course = random.choice(remaining_courses)
                    
                    # Skip SEC/VAC if already taking one
                    if (course.course_type in ['SEC', 'VAC']) and sec_vac_taken:
                        remaining_courses.remove(course)
                        continue
                    
                    # Mark SEC/VAC as taken
                    if course.course_type in ['SEC', 'VAC']:
                        sec_vac_taken = True
                    
                    selected_courses.append(course)
                    remaining_courses.remove(course)
                
                # Create student entries for current semester (no grades yet)
                for course in selected_courses:
                    student_entry = {
                        'Student ID': student_id,
                        'Student Name': f"Student {student_id[1:]}",
                        'Course Code': course.code,
                        'Course Type': course.course_type
                    }
                    students.append(student_entry)
        
        self.stdout.write(self.style.SUCCESS(f'Generated {len(students)} student-course entries'))
        return students

    def create_sheet_connections(self, user, prev_data, curr_data):
        """Create sheet connections with the generated data"""
        # Create previous semester connection
        prev_sheet = SheetConnection.objects.create(
            name="Test Previous Semester",
            sheet_id="mock_previous_semester",
            sheet_name="Sheet1",
            is_current_semester=False,
            semester="Spring 2024",
            created_by=user
        )
        
        # Create current semester connection
        curr_sheet = SheetConnection.objects.create(
            name="Test Current Semester",
            sheet_id="mock_current_semester",
            sheet_name="Sheet1",
            is_current_semester=True,
            semester="Fall 2024",
            created_by=user
        )
        
        # Create column mappings
        CourseMapping.objects.create(
            sheet_connection=prev_sheet,
            student_id_column="Student ID",
            student_name_column="Student Name",
            course_code_column="Course Code",
            course_type_column="Course Type",
            grade_column="Grade",
            mapping_data=json.dumps({
                "Student ID": "Student ID",
                "Student Name": "Student Name",
                "Course Code": "Course Code",
                "Course Type": "Course Type",
                "Grade": "Grade"
            })
        )
        
        CourseMapping.objects.create(
            sheet_connection=curr_sheet,
            student_id_column="Student ID",
            student_name_column="Student Name",
            course_code_column="Course Code",
            course_type_column="Course Type",
            mapping_data=json.dumps({
                "Student ID": "Student ID",
                "Student Name": "Student Name",
                "Course Code": "Course Code",
                "Course Type": "Course Type"
            })
        )
        
        # Save the test data to the database for mock evaluations
        prev_sheet.mock_data = json.dumps(prev_data)
        prev_sheet.save()
        
        curr_sheet.mock_data = json.dumps(curr_data)
        curr_sheet.save()
        
        self.stdout.write(self.style.SUCCESS('Created sheet connections and column mappings'))