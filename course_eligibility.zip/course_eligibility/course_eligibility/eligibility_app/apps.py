from django.apps import AppConfig


class EligibilityAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'eligibility_app'
    verbose_name = 'Course Eligibility Evaluator'
