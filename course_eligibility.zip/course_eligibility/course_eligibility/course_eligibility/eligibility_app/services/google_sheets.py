import os
import json
import pandas as pd
import logging
from typing import List, Dict, Any, Optional, Union
from google.oauth2 import service_account
from googleapiclient.discovery import build
from django.conf import settings

# Get logger
logger = logging.getLogger(__name__)

class GoogleSheetsService:
    """
    Service class for interacting with Google Sheets API
    """
    
    def __init__(self, use_mock=False):
        """Initialize the Google Sheets service"""
        self.use_mock = use_mock or settings.DEBUG
        
        # Only initialize Google API client if not using mock data
        if not self.use_mock:
            try:
                self.credentials = self._get_credentials()
                self.service = build('sheets', 'v4', credentials=self.credentials)
                self.sheets = self.service.spreadsheets()
            except Exception as e:
                logger.warning(f"Failed to initialize Google Sheets API: {str(e)}")
                self.use_mock = True
    
    def _get_credentials(self):
        """Get Google API credentials from the credentials file or environment"""
        credentials_file = settings.GOOGLE_API_CREDENTIALS_FILE
        
        # Check if credentials file exists
        if not credentials_file or not os.path.exists(credentials_file):
            # Try to get credentials from environment variable
            creds_json = ('GOOGLE_API_CREDENTIALS', None)
            if creds_json:
                # Write credentials to a temporary file
                import tempfile
                temp = tempfile.NamedTemporaryFile(delete=False)
                temp.write(creds_json.encode('utf-8'))
                temp.close()
                credentials_file = temp.name
            else:
                raise Exception("Google API credentials not found")
        
        return service_account.Credentials.from_service_account_file(
            credentials_file, scopes=settings.GOOGLE_API_SCOPES
        )
    
    def validate_sheet(self, sheet_id: str, sheet_name: str) -> bool:
        """
        Validate that the provided sheet_id and sheet_name are accessible
        
        Args:
            sheet_id: The ID of the Google Sheet
            sheet_name: The name of the specific sheet/tab
            
        Returns:
            bool: True if sheet is valid and accessible
            
        Raises:
            Exception: If sheet cannot be accessed
        """
        try:
            # Try to get sheet metadata
            sheet_metadata = self.sheets.get(spreadsheetId=sheet_id).execute()
            
            # Verify sheet name exists
            sheet_exists = False
            for sheet in sheet_metadata.get('sheets', []):
                if sheet.get('properties', {}).get('title') == sheet_name:
                    sheet_exists = True
                    break
            
            if not sheet_exists:
                raise Exception(f"Sheet '{sheet_name}' not found in the spreadsheet")
            
            return True
        except Exception as e:
            raise Exception(f"Failed to validate sheet: {str(e)}")
    
    def get_sheet_data(self, sheet_id: str, sheet_name: str, sheet_connection=None) -> pd.DataFrame:
        """
        Retrieve data from a Google Sheet as a pandas DataFrame
        
        Args:
            sheet_id: The ID of the Google Sheet
            sheet_name: The name of the specific sheet/tab
            sheet_connection: Optional SheetConnection model instance
            
        Returns:
            pd.DataFrame: The sheet data as a DataFrame
        """
        # Check if using mock data
        if self.use_mock or (sheet_connection and sheet_connection.mock_data):
            return self._get_mock_data(sheet_connection)
        
        try:
            # Get sheet range to determine data dimensions
            sheet_metadata = self.sheets.get(spreadsheetId=sheet_id).execute()
            
            # Find the specified sheet
            sheet_info = None
            for sheet in sheet_metadata.get('sheets', []):
                if sheet.get('properties', {}).get('title') == sheet_name:
                    sheet_info = sheet
                    break
            
            if not sheet_info:
                raise Exception(f"Sheet '{sheet_name}' not found")
            
            # Get sheet dimensions
            grid_props = sheet_info.get('properties', {}).get('gridProperties', {})
            row_count = grid_props.get('rowCount', 0)
            col_count = grid_props.get('columnCount', 0)
            
            # Construct range
            cell_range = f"{sheet_name}!A1:{self._column_letter(col_count)}{row_count}"
            
            # Get sheet data
            result = self.sheets.values().get(
                spreadsheetId=sheet_id,
                range=cell_range
            ).execute()
            
            values = result.get('values', [])
            if not values:
                return pd.DataFrame()
            
            # Convert to DataFrame
            headers = values[0]
            data = values[1:] if len(values) > 1 else []
            
            # Ensure all rows have the same length as headers
            padded_data = []
            for row in data:
                if len(row) < len(headers):
                    row.extend([''] * (len(headers) - len(row)))
                padded_data.append(row)
            
            return pd.DataFrame(padded_data, columns=headers)
        
        except Exception as e:
            # If real data fetch fails and we have sheet_connection, try mock data
            if sheet_connection and hasattr(sheet_connection, 'mock_data') and sheet_connection.mock_data:
                logger.warning(f"Failed to get real sheet data: {str(e)}. Falling back to mock data.")
                return self._get_mock_data(sheet_connection)
            raise Exception(f"Failed to get sheet data: {str(e)}")
    
    def _get_mock_data(self, sheet_connection):
        """Get mock data from a SheetConnection model instance"""
        if not sheet_connection or not hasattr(sheet_connection, 'mock_data') or not sheet_connection.mock_data:
            # Create an empty dataframe with standard columns
            return pd.DataFrame(columns=['Student ID', 'Student Name', 'Course Code'])
        
        try:
            # Load mock data from the SheetConnection
            mock_data = sheet_connection.get_mock_data()
            
            # If mock_data is not a list, something is wrong
            if not isinstance(mock_data, list):
                logger.warning("Mock data is not a list. Creating empty DataFrame.")
                return pd.DataFrame(columns=['Student ID', 'Student Name', 'Course Code'])
            
            # Create a DataFrame from the mock data
            if not mock_data:  # Empty list
                return pd.DataFrame(columns=['Student ID', 'Student Name', 'Course Code'])
            
            # Extract all keys from the first dict to use as columns
            if isinstance(mock_data[0], dict):
                df = pd.DataFrame(mock_data)
            else:
                # If not dict, just return empty DataFrame
                df = pd.DataFrame(columns=['Student ID', 'Student Name', 'Course Code'])
            
            return df
            
        except Exception as e:
            logger.error(f"Error loading mock data: {str(e)}")
            return pd.DataFrame(columns=['Student ID', 'Student Name', 'Course Code'])
    
    def update_sheet_data(self, sheet_id: str, sheet_name: str, 
                          data: pd.DataFrame, start_cell: str = 'A1', 
                          sheet_connection=None) -> bool:
        """
        Update data in a Google Sheet
        
        Args:
            sheet_id: The ID of the Google Sheet
            sheet_name: The name of the specific sheet/tab
            data: DataFrame containing the data to update
            start_cell: The cell where data starts (default: A1)
            sheet_connection: Optional SheetConnection model instance
            
        Returns:
            bool: True if update was successful
        """
        # If using mock data, just update the sheet_connection.mock_data
        if self.use_mock and sheet_connection:
            try:
                # Convert DataFrame to list of dicts
                records = data.to_dict('records')
                sheet_connection.mock_data = json.dumps(records)
                sheet_connection.save()
                logger.info(f"Updated mock data for {sheet_connection}")
                return True
            except Exception as e:
                logger.error(f"Failed to update mock data: {str(e)}")
                raise Exception(f"Failed to update mock data: {str(e)}")
                
        try:
            # Convert DataFrame to list of lists
            values = [data.columns.tolist()]  # Header row
            values.extend(data.values.tolist())
            
            # Calculate range
            end_col = self._column_letter(len(data.columns))
            end_row = len(values)
            
            # Extract row and column from start_cell
            col_letter = ''.join(filter(str.isalpha, start_cell))
            row_num = int(''.join(filter(str.isdigit, start_cell)))
            
            # Calculate end cell
            end_col_idx = self._column_index(col_letter) + len(data.columns) - 1
            end_col_letter = self._column_letter(end_col_idx)
            end_row_num = row_num + len(values) - 1
            
            cell_range = f"{sheet_name}!{start_cell}:{end_col_letter}{end_row_num}"
            
            # Update sheet
            body = {
                'values': values
            }
            
            result = self.sheets.values().update(
                spreadsheetId=sheet_id,
                range=cell_range,
                valueInputOption='USER_ENTERED',
                body=body
            ).execute()
            
            return True
        
        except Exception as e:
            # If real update fails and we have sheet_connection with mock_data, update mock data
            if sheet_connection and hasattr(sheet_connection, 'mock_data'):
                logger.warning(f"Failed to update sheet: {str(e)}. Updating mock data instead.")
                records = data.to_dict('records')
                sheet_connection.mock_data = json.dumps(records)
                sheet_connection.save()
                return True
            raise Exception(f"Failed to update sheet data: {str(e)}")
    
    def append_column(self, sheet_id: str, sheet_name: str, 
                      column_name: str, values: List[Any], 
                      sheet_connection=None) -> bool:
        """
        Append a new column to the sheet
        
        Args:
            sheet_id: The ID of the Google Sheet
            sheet_name: The name of the specific sheet/tab
            column_name: The name of the new column
            values: List of values for the column
            sheet_connection: Optional SheetConnection model instance
            
        Returns:
            bool: True if append was successful
        """
        try:
            # Get current sheet data
            df = self.get_sheet_data(sheet_id, sheet_name, sheet_connection)
            
            # Check if column already exists
            if column_name in df.columns:
                # Update existing column
                df[column_name] = values
            else:
                # Add new column
                df[column_name] = values
            
            # Update sheet
            return self.update_sheet_data(sheet_id, sheet_name, df, sheet_connection=sheet_connection)
        
        except Exception as e:
            raise Exception(f"Failed to append column: {str(e)}")
    
    def _column_letter(self, column_index: int) -> str:
        """
        Convert column index to letter (1 = A, 27 = AA, etc.)
        """
        result = ""
        while column_index > 0:
            column_index, remainder = divmod(column_index - 1, 26)
            result = chr(65 + remainder) + result
        return result
    
    def _column_index(self, column_letter: str) -> int:
        """
        Convert column letter to index (A = 1, AA = 27, etc.)
        """
        result = 0
        for char in column_letter:
            result = result * 26 + (ord(char.upper()) - ord('A') + 1)
        return result
