from django import forms
from django.core.exceptions import ValidationError
from .models import SheetConnection, EligibilityEvaluation, CourseMapping
from .services.google_sheets import GoogleSheetsService


class SheetConnectionForm(forms.ModelForm):
    """Form for connecting to Google Sheets"""
    
    class Meta:
        model = SheetConnection
        fields = ['name', 'sheet_id', 'sheet_name', 'semester', 'is_current_semester']
    
    def clean(self):
        cleaned_data = super().clean()
        sheet_id = cleaned_data.get('sheet_id')
        sheet_name = cleaned_data.get('sheet_name')
        
        if sheet_id and sheet_name:
            try:
                # Attempt to validate the Google Sheet connection
                gs_service = GoogleSheetsService()
                gs_service.validate_sheet(sheet_id, sheet_name)
            except Exception as e:
                raise ValidationError(f"Unable to connect to Google Sheet: {str(e)}")
                
        # Check if another connection is already marked as current semester
        is_current = cleaned_data.get('is_current_semester')
        if is_current:
            current_connections = SheetConnection.objects.filter(is_current_semester=True)
            if self.instance.pk:
                current_connections = current_connections.exclude(pk=self.instance.pk)
            if current_connections.exists():
                raise ValidationError(
                    "Another sheet is already marked as current semester. "
                    "Please update that connection first."
                )
                
        return cleaned_data


class CourseMappingForm(forms.ModelForm):
    """Form for mapping Google Sheet columns to fields"""
    
    class Meta:
        model = CourseMapping
        fields = ['student_id_column', 'student_name_column', 'course_code_column']
    
    def clean(self):
        cleaned_data = super().clean()
        # Ensure column names are unique
        columns = [
            cleaned_data.get('student_id_column'),
            cleaned_data.get('student_name_column'),
            cleaned_data.get('course_code_column')
        ]
        
        if len(set(columns)) != len(columns):
            raise ValidationError("Column names must be unique")
        
        return cleaned_data


class EvaluationForm(forms.ModelForm):
    """Form for setting up eligibility evaluation"""
    
    class Meta:
        model = EligibilityEvaluation
        fields = ['current_sheet', 'previous_sheet', 'result_column']
    
    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        
        # Filter sheet connections to those created by the current user
        if user:
            self.fields['current_sheet'].queryset = SheetConnection.objects.filter(
                created_by=user, is_current_semester=True
            )
            self.fields['previous_sheet'].queryset = SheetConnection.objects.filter(
                created_by=user, is_current_semester=False
            )
    
    def clean(self):
        cleaned_data = super().clean()
        current_sheet = cleaned_data.get('current_sheet')
        previous_sheet = cleaned_data.get('previous_sheet')
        
        if current_sheet and previous_sheet:
            if current_sheet == previous_sheet:
                raise ValidationError("Current and previous sheets must be different")
                
            # Validate that current sheet is marked as current semester
            if not current_sheet.is_current_semester:
                raise ValidationError("The selected current sheet must be marked as the current semester")
                
            # Validate that previous sheet is not marked as current semester
            if previous_sheet.is_current_semester:
                raise ValidationError("The selected previous sheet must not be marked as the current semester")
        
        return cleaned_data
