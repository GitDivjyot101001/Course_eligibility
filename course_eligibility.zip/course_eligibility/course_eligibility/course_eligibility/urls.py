"""
URL configuration for course_eligibility project.
"""

from django.contrib import admin
from django.urls import path, include

# Import our custom admin site
from eligibility_app.admin import admin_site

urlpatterns = [
    path('admin/', admin.site.urls),          # Default Django admin
    path('eligibility/', admin_site.urls),     # Custom Eligibility Admin
    path('', include('eligibility_app.urls')), # App URLs
]

# Customize default admin site headers
admin.site.site_header = 'Course Eligibility Administration'
admin.site.site_title = 'Course Eligibility Admin'
admin.site.index_title = 'Welcome to Course Eligibility Evaluator'