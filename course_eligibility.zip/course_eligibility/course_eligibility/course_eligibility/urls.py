"""
URL configuration for course_eligibility project.
"""

from django.contrib import admin
from django.urls import path, include

# Import our custom admin site
from eligibility_app.admin import admin_site

urlpatterns = [
    path('admin/', admin.site.urls),  # Keep the default admin
    path('eligibility/', admin_site.urls),  # Add our custom admin site
    path('', include('eligibility_app.urls')),
]

# Customize admin site
admin.site.site_header = 'Course Eligibility Administration'
admin.site.site_title = 'Course Eligibility Admin'
admin.site.index_title = 'Welcome to Course Eligibility Evaluator'
